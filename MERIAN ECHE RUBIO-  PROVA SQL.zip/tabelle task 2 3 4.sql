-- Task 2: Descrizione della struttura delle tabelle
CREATE DATABASE IF NOT EXISTS ToysGroup;
USE ToysGroup;
DROP TABLE IF EXISTS Sales;
DROP TABLE IF EXISTS Region;
DROP TABLE IF EXISTS Product;
CREATE TABLE Product (
    ProductID INT PRIMARY KEY,
    Name VARCHAR(100),
    Category VARCHAR(100)
);

CREATE TABLE Region (
    RegionID INT PRIMARY KEY,
    Name VARCHAR(100)
);

CREATE TABLE Sales (
    SaleID INT PRIMARY KEY,
    Date DATE,
    Amount DECIMAL(10, 2),
    ProductID INT,
    RegionID INT,
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);
-- Task 3: Popola le tabelle utilizzando dati a tua discrezione (sono sufficienti pochi record per tabella; riporta le query utilizzate

INSERT INTO Product (ProductID, Name, Category)
VALUES
(1, 'Bicicletta-100', 'Biciclette'),
(2, 'Casco Sport', 'Accessori'),
(3, 'Guanti Invernali', 'Abbigliamento'),
(4, 'Bicicletta-200', 'Biciclette'),
(5, 'Catena Bicicletta', 'Accessori');

INSERT INTO Region (RegionID, Name)
VALUES
(1, 'Europa Occidentale'),
(2, 'Europa Meridionale'),
(3, 'Nord America'),
(4, 'Sud America'),
(5, 'Asia Orientale');

INSERT INTO Sales (SaleID, Date, Amount, ProductID, RegionID)
VALUES
(1, '2024-01-10', 100.50, 1, 1),
(2, '2024-01-12', 200.00, 2, 2),
(3, '2024-01-15', 150.75, 3, 3),
(4, '2024-01-20', 300.25, 4, 4),
(5, '2024-01-25', 400.00, 5, 5);

SELECT * FROM Product;
SELECT * FROM Region;
SELECT * FROM Sales;
SELECT 
    Sales.SaleID, 
    Sales.Date, 
    Sales.Amount, 
    Product.Name AS NomeProdotto, 
    Region.Name AS NomeRegione
FROM Sales
JOIN Product ON Sales.ProductID = Product.ProductID
JOIN Region ON Sales.RegionID = Region.RegionID;

USE ToysGroup;
-- 1) Verificación de claves primarias (PK): Para cada tabla, se verifica la unicidad de los valores de las claves primarias (ProductID, RegionID, SaleID).
SELECT ProductID, COUNT(*) AS Count
FROM Product
GROUP BY ProductID
HAVING COUNT(*) > 1;

SELECT RegionID, COUNT(*) AS Count
FROM Region
GROUP BY RegionID
HAVING COUNT(*) > 1;

SELECT SaleID, COUNT(*) AS Count
FROM Sales
GROUP BY SaleID
HAVING COUNT(*) > 1;
 -- 2)Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)
SELECT 
    Sales.SaleID, 
    Sales.Date, 
    Product.Name AS NomeProdotto, 
    Product.Category AS CategoriaProdotto, 
    Region.Name AS NomeRegione,
    CASE 
        WHEN DATEDIFF(CURDATE(), Sales.Date) > 180 THEN TRUE
        ELSE FALSE
    END AS PiùDi180Giorni
FROM Sales
JOIN Product ON Sales.ProductID = Product.ProductID
JOIN Region ON Sales.RegionID = Region.RegionID;

-- 3)Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate nell’ultimo anno censito. (ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). Nel result set devono comparire solo il codice prodotto e il totale venduto.
SELECT 
    ProductID, 
    SUM(Amount) AS TotaleVenduto
FROM Sales
WHERE YEAR(Date) = YEAR(CURDATE()) - 1
GROUP BY ProductID
HAVING SUM(Amount) > (
    SELECT AVG(SommaVendite)
    FROM (
        SELECT SUM(Amount) AS SommaVendite
        FROM Sales
        WHERE YEAR(Date) = YEAR(CURDATE()) - 1
        GROUP BY ProductID
    ) AS MediaVendite
);
-- 4) Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno
SELECT 
    Product.Name AS NomeProdotto, 
    YEAR(Sales.Date) AS Anno, 
    SUM(Sales.Amount) AS FatturatoTotale
FROM Sales
JOIN Product ON Sales.ProductID = Product.ProductID
GROUP BY Product.Name, YEAR(Sales.Date);
-- 5) Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente
SELECT 
    Region.Name AS NomeRegione, 
    YEAR(Sales.Date) AS Anno, 
    SUM(Sales.Amount) AS FatturatoTotale
FROM Sales
JOIN Region ON Sales.RegionID = Region.RegionID
GROUP BY Region.Name, YEAR(Sales.Date)
ORDER BY YEAR(Sales.Date), FatturatoTotale DESC;
-- 6)Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato
SELECT 
    Product.Category AS Categoria, 
    COUNT(Sales.SaleID) AS NumeroVendite
FROM Sales
JOIN Product ON Sales.ProductID = Product.ProductID
GROUP BY Product.Category
ORDER BY NumeroVendite DESC
LIMIT 1;
-- 7)Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti
SELECT Product.ProductID, Product.Name 
FROM Product
LEFT JOIN Sales ON Product.ProductID = Sales.ProductID
WHERE Sales.ProductID IS NULL;

SELECT ProductID, Name 
FROM Product
WHERE ProductID NOT IN (
    SELECT DISTINCT ProductID 
    FROM Sales
);
-- 8)	Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili (codice prodotto, nome prodotto, nome categoria)
CREATE VIEW VistaProdottiDenormalizzata AS
SELECT 
    Product.ProductID, 
    Product.Name AS NomeProdotto, 
    Product.Category AS Categoria
FROM Product;
-- 9)	Creare una vista per le informazioni geografiche
CREATE VIEW VistaInformazioniGeografiche AS
SELECT 
    Region.RegionID, 
    Region.Name AS NomeRegione
FROM Region;
